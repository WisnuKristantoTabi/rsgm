<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Login::index');
$routes->post('/auth', 'Login::auth');
$routes->get('/logout', 'Login::logout');

// $routes->group('', ['filter' => 'auth'], static function ($routes) {
// $routes->group('', ['filter' => ''], static function ($routes) {
$routes->get('/signup', 'Register::index');
$routes->post('/register', 'Register::store');

$routes->get('/dashboard', 'Dashboard::index');

$routes->get('/recordmedical', 'RecordMedical::index');
$routes->get('/recordmedical/show/(:any)', 'RecordMedical::show/$1');
$routes->get('/recordmedical/add', 'RecordMedical::add');
$routes->post('/recordmedical/store', 'RecordMedical::store');
$routes->get('/recordmedical/edit/(:any)', 'RecordMedical::edit/$1');
$routes->post('/recordmedical/update', 'RecordMedical::update');
// });
